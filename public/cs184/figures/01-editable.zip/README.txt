CS184 editable teaching diagrams
Each PPTX contains native PowerPoint shapes, labels and connectors.
The corresponding JSON is the pptdraw operation source.
Figure explanations appear in the course notes and slide speaker notes.
These are original teaching diagrams, not the Berkeley lecture slides.
