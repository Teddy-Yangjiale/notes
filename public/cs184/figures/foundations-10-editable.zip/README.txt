Three original teaching figures added in the foundations v2 revision.
PPTX contains editable native shapes; JSON contains pptdraw operations.
This package does not include the older matplotlib diagrams or Berkeley slides.
