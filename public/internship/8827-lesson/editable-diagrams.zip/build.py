from pathlib import Path
import json, subprocess, sys, os, shutil, zipfile
R=Path(r'D:\Draw'); W=Path(__file__).parent
O=R/'out/internship_8827_deep_20261110'; O.mkdir(parents=True,exist_ok=True)
F=Path(r'D:\notes\public\internship\8827-lesson')
def txt(n,t,x,y,w,h=.35,size=10,color='243342'):
    return dict(op='add_text',name=n,text=t,x=x,y=y,w=w,h=h,font='Microsoft YaHei',font_size=size,color=color)
def box(n,t,x,y,w=1.15,h=.65,style='blue'):
    return dict(op='add_shape',name=n,text=t,x=x,y=y,w=w,h=h,font='Microsoft YaHei',font_size=10,style=style)
def edge(n,a,b): return dict(op='add_connector',name=n,**{'from':a,'to':b},arrow='end',line_width=1)
def photo(n,x,y,w,h): return dict(op='add_asset',name=n,path=str(F/'3484-rgb.jpg'),x=x,y=y,w=w,h=h,source_kind='experiment',source='Saved undistorted frame 003484.jpg; see provenance.json')
figs={}
ops=[photo('photo',.13,.13,6.9,3.88125)]
for name,u,v,label in [('A',960,900,'A  道路：改用平面'),('B',978,546,'B  远景：初始化候选'),('C',1500,600,'C  卡车：屏蔽监督'),('D',840,180,'D  天空：贴图解释')]:
    x=.13+6.9*u/1920;y=.13+3.88125*v/1080
    ops += [dict(op='add_shape',name='point'+name,shape='ellipse',x=x-.045,y=y-.045,w=.09,h=.09,text='',style='orange'),
            box('mark'+name,name,x+.07,y-.23,.27,.24,'orange')]
    i='ABCD'.index(name)
    ops.append(txt('legend'+name,label,.15+i*1.73,4.12,1.69,.38,9))
figs['frame-landmarks']=('7.16x4.65',ops)
ops=[photo('input',.15,.2,2.25,1.2656),txt('fixed','固定观测：照片 / K / 位姿\n标签 / 深度目标 / 权重',2.62,.26,3.9,.66,12),
     txt('fixednote','仅训练高斯、曝光与天空；不回传到 SAM / DA3。',2.62,1.02,4.2,.45,9)]
nodes=[('params','高斯参数\nN × 59',.15,'blue'),('render','可微渲染\nRGB / A / D',1.55,'blue'),('compose','曝光 + 天空\n合成照片',2.95,'blue'),('loss','与固定观测比较\n总损失 L',4.35,'orange'),('adam','反传 + 策略\nAdam 更新',5.75,'green')]
for n,t,x,c in nodes:ops.append(box(n,t,x,1.9,1.25,.65,c))
for i in range(4):ops.append(edge('forward'+str(i),nodes[i][0],nodes[i+1][0]))
ops += [dict(op='add_detour',name='feedback',**{'from':'adam','to':'params'},side='bottom',offset=.65,dash='dash',arrow='end',label='下一步用更新后的参数再次渲染'),
        txt('caveat','MCMC 真正替换 Parameter 时，旧梯度的去向必须单独检查（见第 17 节）。',.35,3.48,6.5,.4,9)]
figs['gradient-loop']=('7.16x4.05',ops)
ops=[photo('input',.15,.15,2.5,1.40625),txt('b','同一真实像素 B： (978, 546)',2.85,.22,4.0,.4,13),
     txt('values','D = 60.783840 m\nRGB = (215, 216, 221)\n候选通过筛选 ≠ 已证明几何正确',2.85,.76,4.0,.9,11)]
stages=[('ray','像素 → 相机射线',.15,'r = (0.006977,\n0.010147, 1)'),('camera','乘深度 D',1.9,'Xc = (0.424108,\n0.616761, 60.783840)'),('world','旋转 + 相机中心',3.65,'μ = (10.337301,\n25.652264, 6.355063)'),('gaussian','补全高斯参数',5.4,'s = (0.3, 0.3, 0.3)\no = 0.5；q = 单位旋转')]
for n,t,x,detail in stages:
    ops += [box(n,t,x,1.95,1.6,.58,'orange' if n=='world' else 'blue'),txt(n+'detail',detail,x,2.68,1.6,.75,9)]
for i in range(3):ops.append(edge('e'+str(i),stages[i][0],stages[i+1][0]))
ops.append(txt('bottom','μ 是训练局部坐标；保存时加 ORG 恢复全局 ENU。颜色按 SH 形式初始化。',.3,3.55,6.6,.4,9))
figs['depth-to-gaussian']=('7.16x4.1',ops)
tasks=[]
def cli(*args):
    p=subprocess.run([sys.executable,'-m','pptdraw',*map(str,args)],cwd=R,capture_output=True,text=True,encoding='utf-8',env={**os.environ,'PYTHONIOENCODING':'utf-8'})
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
    return p.stdout
for name,(size,ops) in figs.items():
    ops += [dict(op='set_caption',text='真实帧3484与当前保存输入的CPU诊断；原生可编辑图示，不是训练回放。完整定义和来源见8827课堂笔记。'),dict(op='normalize_z')]
    f=W/(name+'.json');f.write_text(json.dumps({'ops':ops},ensure_ascii=False,indent=2),encoding='utf-8')
    ppt=O/(name+'.pptx')
    if ppt.exists(): raise RuntimeError('Inspect existing deck before editing: '+str(ppt))
    cli('new',ppt,'--size',size);cli('apply',ppt,f)
    (W/(name+'-inspect.json')).write_text(cli('inspect',ppt,'--json'),encoding='utf-8')
    (W/(name+'-lint.txt')).write_text(cli('lint',ppt),encoding='utf-8')
    tasks.append(dict(pptx=str(ppt),png=str(F/(name+'.png'))))
(W/'render-tasks.json').write_text(json.dumps(tasks),encoding='utf-8')
shutil.copyfile(R/'.pptdraw/internship_notes_20261109/render.ps1',W/'render.ps1')
print('Created',len(tasks),'native diagrams')
