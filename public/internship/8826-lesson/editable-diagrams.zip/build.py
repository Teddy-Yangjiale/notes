from pathlib import Path
import json, subprocess, sys, os, shutil
R=Path(r'D:\Draw');W=Path(__file__).parent;O=R/'out/internship_8826_deep_20261110';O.mkdir(parents=True,exist_ok=True);F=Path(r'D:\notes\public\internship\8826-lesson')
def text(n,t,x,y,w,h=.35,size=10):return dict(op='add_text',name=n,text=t,x=x,y=y,w=w,h=h,font='Microsoft YaHei',font_size=size,color='243342')
def box(n,t,x,y,w=1.5,h=.65,style='blue'):
 if isinstance(h,str):style,h=h,.65
 return dict(op='add_shape',name=n,text=t,x=x,y=y,w=w,h=h,font='Microsoft YaHei',font_size=10,style=style)
def edge(n,a,b):return dict(op='add_connector',name=n,**{'from':a,'to':b},arrow='end',line_width=1)
def photo(n,x,y,w,h):return dict(op='add_asset',name=n,path=str(F/'3540-raw.jpg'),x=x,y=y,w=w,h=h,source_kind='experiment',source='Saved real front-camera frame 003540.jpg; provenance.json')
figs={};ops=[photo('photo',.13,.13,6.9,3.88125)]
for name,u,v,label in [('A',480.13,449.92,'A 道路：定尺度后让位'),('B',207.12,302.54,'B 路边：环境点候选'),('C',528.39,327.95,'C 车辆：掩膜拒绝'),('D',480.13,99.24,'D 天空：低置信拒绝')]:
 x=.13+6.9*u/960;y=.13+3.88125*v/540;ops += [dict(op='add_shape',name='point'+name,shape='ellipse',x=x-.04,y=y-.04,w=.08,h=.08,text='',style='orange'),box('mark'+name,name,x+.06,y-.22,.25,.24,'orange'),text('legend'+name,label,.15+'ABCD'.index(name)*1.73,4.13,1.7,.4,8.5)]
figs['frame-landmarks']=('7.16x4.65',ops)
ops=[photo('photo',.15,.2,1.6,.9),text('id','真实照片 3540\n960 × 540',.2,1.2,1.5,.6),box('strip','道路条带 + GNSS\n相邻运动约束',2.0,.25,1.8),box('track','t01f 平面轨迹\nE / N / 航向',4.15,.25,2.6),edge('a','strip','track'),
 box('abot','ABot 点图\n420 × 756 × 3',.15,2.05,1.6),box('range','标定射线 + 路面尺度\n只取模型点的距离',2.0,2.05,2.05),box('cloud','t04 筛点 / 体素融合\n40 m 环境点云瓦片',4.4,2.05,2.35),edge('b','abot','range'),edge('c','range','cloud'),edge('d','track','cloud'),
 box('ba','g11 BA：图像特征\n完整六自由度 + 稀疏点',2.0,3.7,2.05,'orange'),box('gs','独立输出 gs/ba/*.npz\n下游显式选择 + 保护',4.4,3.7,2.35,'orange'),edge('e','ba','gs'),
 dict(op='add_detour',name='fork',**{'from':'track','to':'ba'},side='right',offset=.16,arrow='end'),text('note','t04 当前读取 track0903.npz；图中没有 BA → t04 的已实现连线。',.3,4.7,6.5,.5,10)]
figs['actual-dataflow']=('7.16x5.4',ops)
ops=[photo('photo',.15,.15,2.5,1.40625),text('sample','同一真实像素 B：模型格点 (163, 236)',2.85,.2,4.0,.4,11),text('values','模型点范数 = 1.583194\n平滑尺度 = 9.148392 m / 模型单位\n米制距离 = 14.483683 m',2.85,.75,4.0,.9,10)]
nodes=[('ray','去畸变 + 单位化',.15,'相机射线\n(-.43581, .05623, .89828)'),('vehicle','安装旋转 + 相机高',1.9,'车体系点\n(-5.85320, 13.24567, 1.73835)'),('world','航向旋转 + EN 平移',3.65,'ENU 点\n(-843.29946, -2848.29775,\n1.73835)'),('tile','筛选 + 跨帧去重',5.4,'6 cm 体素选最近观测\n不是对所有点求平均')]
for n,t,x,s in nodes:ops += [box(n,t,x,1.9,1.6,.65),text(n+'data',s,x,2.75,1.6,.95,8.5)]
for i in range(3):ops.append(edge('e'+str(i),nodes[i][0],nodes[i+1][0]))
figs['point-to-world']=('7.16x4.05',ops)
ops=[text('obs','固定照片观测：21,397 个二维点\n相机 61 个；三维点 5,234 个',.25,.2,6.6,.7,12),box('r','投影 − 实测像素\n每条观测 2 个残差',.2,1.3,1.5),box('j','局部线性化\nJc: 2 × 6 / Jx: 2 × 3',1.95,1.3,2.0),box('h','法方程分块\n相机 / 点 / 交叉项',4.2,1.3,2.6),edge('a','r','j'),edge('b','j','h'),box('schur','消去点增量\n解 366 × 366 相机系统',4.2,2.7,2.6,'orange'),box('back','回代每个点\n各自的 3 × 3 块',1.95,2.7,2.0,'orange'),box('accept','更新位姿和点\n真实代价下降才接受',.2,2.7,1.5,'green'),edge('c','h','schur'),edge('d','schur','back'),edge('e','back','accept'),text('foot','这些是已保存 s1_00 的规模；本次只检查推导和数据，没有重新运行 BA。',.25,3.75,6.6,.5,10)]
figs['ba-schur']=('7.16x4.5',ops)
def cli(*args):
 p=subprocess.run([sys.executable,'-m','pptdraw',*map(str,args)],cwd=R,capture_output=True,text=True,encoding='utf-8',env={**os.environ,'PYTHONIOENCODING':'utf-8'})
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 return p.stdout
tasks=[]
for name,(size,ops) in figs.items():
 ops += [dict(op='set_caption',text='8826 课堂笔记：真实帧3540、保存的中间结果与CPU诊断。来源和适用范围见正文。'),dict(op='normalize_z')];f=W/(name+'.json');f.write_text(json.dumps({'ops':ops},ensure_ascii=False,indent=2),encoding='utf-8');ppt=O/(name+'.pptx')
 if ppt.exists():
  previous=cli('inspect',ppt,'--json');(W/(name+'-before.json')).write_text(previous,encoding='utf-8')
  if name=='frame-landmarks':tasks.append(dict(pptx=str(ppt),png=str(F/(name+'.png'))));continue
 else:cli('new',ppt,'--size',size)
 cli('apply',ppt,f);(W/(name+'-inspect.json')).write_text(cli('inspect',ppt,'--json'),encoding='utf-8');(W/(name+'-lint.txt')).write_text(cli('lint',ppt),encoding='utf-8');tasks.append(dict(pptx=str(ppt),png=str(F/(name+'.png'))))
(W/'render-tasks.json').write_text(json.dumps(tasks),encoding='utf-8');shutil.copyfile(R/'.pptdraw/internship_8827_deep_20261110/render.ps1',W/'render.ps1');print('Created',len(tasks),'native diagrams')
